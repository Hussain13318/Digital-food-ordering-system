# Function to login user
def login_user():
    global user_gmail, user_password  # Use global variables to store credentials

    # Check if user has registered before
    if user_gmail == '' or user_password == '':
        print("Please set your Gmail and password first.")
        user_gmail = input("Enter your Gmail to set: ")
        user_password = input("Enter your password to set: ")
        print("Your Gmail and password have been set successfully.")
        return False  # User has set their credentials, now return False to allow the first login

    # If credentials are already set, proceed to login
    print("Please login to avail our services")
    gmail = input("Enter your Gmail: ")
    password = input("Enter your password: ")
    otp = 3252
    OTP = int(input(f"We have sent an OTP to your device\nOTP is {otp}\nEnter it to confirm: "))

    if gmail == user_gmail and password == user_password and OTP == otp:
        print("You have successfully logged in!")
        return True  # User logged in successfully
    else:
        print("Invalid credentials or OTP. Please try again.")
        return False  # Login failed

# Initialize user credentials as empty strings
user_gmail = ''
user_password = ''

total_bill = 0  # To track the total bill
item_names = []  # To store names of ordered items
quantity_array = []  # To store quantities of ordered items
price_array = []  # To store prices of ordered items

# Function to display the bill details
def displayBill():
    global total_bill  # Declare total_bill as global
    print("\nYour bill details are as follows:")
    for i in range(len(item_names)):#number of items
        if quantity_array[i] > 0:
            print(f"{item_names[i]} - Quantity: {quantity_array[i]} - Price: {price_array[i]} Rps")
    print(f"Total Bill: {total_bill} Rps")

# Function to ask for quantity and update the bill
def qty(price, item_name):
    global total_bill
    quantity = int(input(f"\nEnter the quantity of {item_name} you want: "))
    
    # Store item details
    item_names.append(item_name)  # Item chosen
    quantity_array.append(quantity)  # Quantity ordered // end of list
    price_array.append(price * quantity)  # Total price for that item (price * quantity)
    
    total_bill += price_array[-1]  # Update total bill go to last element  -1
    return total_bill

# Function to display the menu and process food orders
def menu():
    global total_bill  # Declare total_bill as global
    print("\nEnter your choice of Food:")
    print("1. Fast Food")
    print("2. Desi Food")
    print("3. Drinks")
    print("4. Desserts")
    print("5. Ice Cream")
    choice = int(input("Your choice: "))

    if choice == 2:  # Desi food menu
        print("\nYou chose Desi Food. Choose from the menu below:")
        print("1. Biryani = 800 Rps")
        print("2. Nihari = 1200 Rps")
        print("3. Haleem = 300 Rps")
        print("4. Chicken Karahi = 1800 Rps")
        choice = int(input("Enter your choice: "))

        if choice == 1:
            print("You chose Biryani.\nPrice of Biryani is 800 Rps.")
            total_bill = qty(800, "Biryani")
        elif choice == 2:
            print("You chose Nihari.\nPrice of Nihari is 1200 Rps.")
            total_bill = qty(1200, "Nihari")
        elif choice == 3:
            print("You chose Haleem.\nPrice of Haleem is 300 Rps.")
            total_bill = qty(300, "Haleem")
        elif choice == 4:
            print("You chose Chicken Karahi.\nPrice of Chicken Karahi is 1800 Rps.")
            total_bill = qty(1800, "Chicken Karahi")
        else:
            print("Invalid choice! Please select a valid option.")
    
    elif choice == 1:  # Fast food menu
        print("\nYou chose Fast Food. Choose from the menu below:")
        print("1. Burger = 500 Rps")
        print("2. Pizza = 1000 Rps")
        print("3. Fries = 250 Rps")
        print("4. Chicken Wings = 600 Rps")
        choice = int(input("Enter your choice: "))

        if choice == 1:
            print("You chose Burger.\nPrice of Burger is 500 Rps.")
            total_bill = qty(500, "Burger")
        elif choice == 2:
            print("You chose Pizza.\nPrice of Pizza is 1000 Rps.")
            total_bill = qty(1000, "Pizza")
        elif choice == 3:
            print("You chose Fries.\nPrice of Fries is 250 Rps.")
            total_bill = qty(250, "Fries")
        elif choice == 4:
            print("You chose Chicken Wings.\nPrice of Chicken Wings is 600 Rps.")
            total_bill = qty(600, "Chicken Wings")
        else:
            print("Invalid choice! Please select a valid option.")
    
    elif choice == 3:  # Drinks menu
        print("\nYou chose Drinks. Choose from the menu below:")
        print("1. Soft Drink = 50 Rps")
        print("2. Water = 30 Rps")
        print("3. Juice = 100 Rps")
        print("4. Tea = 30 Rps")
        choice = int(input("Enter your choice: "))

        if choice == 1:
            print("You chose Soft Drink.\nPrice of Soft Drink is 50 Rps.")
            total_bill = qty(50, "Soft Drink")
        elif choice == 2:
            print("You chose Water.\nPrice of Water is 30 Rps.")
            total_bill = qty(30, "Water")
        elif choice == 3:
            print("You chose Juice.\nPrice of Juice is 100 Rps.")
            total_bill = qty(100, "Juice")
        elif choice == 4:
            print("You chose Tea.\nPrice of Tea is 30 Rps.")
            total_bill = qty(30, "Tea")
        else:
            print("Invalid choice! Please select a valid option.")
    
    else:
        print("Invalid choice! Please select a valid option.")
    
    displayBill()

# Main function
def main():
    global total_bill  # Declare total_bill as global
    name = input("Welcome to Over Dose\nPlease enter your name by whom you want us to call you: ")
    print(f"Hi {name}, hope you are doing good. Please login first to avail our services")

    # Try to login until successful
    while not login_user():
        print("Please try logging in again.")

    # Proceed with the rest of the program after successful login
    print(f"Hi {name}, you are now logged in!\n")
    
    # Main loop after login
    login = 'y'
    while login.lower() == 'y':
        print("\nEnter from the list below what you want to choose:")
        print("1. Menu")
        print("2. Help and Support")
        print("3. Vouchers")
        print("4. Exiting")
        print("5. Checkout")
        option = int(input("You chose: "))
        
        if option == 1:
            menu()  # Call menu function to display food options
        elif option == 2:
            print(f"You chose Help and Support\nHi {name}, we are here to help you.\n")
            print("If you want to complain call on 321-4567890\nIf you want to track your order call on 0313-0987654\n"
                  "If you want to do an inquiry call on 0312-3579085\nIf you want to give a suggestion call on 0313-1357982\n"
                  "If you want to mail us use OverDose@gmail.com")
        elif option == 3:
            vouch = int(input("You chose Vouchers\nBelow are all the vouchers available:\n"
                              "1. Birthday Voucher\n2. Family Time\n3. Weekend Special\n4. Student Discount\n5. Sir Khawaja Discount\nYour option: "))
            if vouch == 1:
                print("Birthday discount: Enter HBD at checkout to get 5% off")
            elif vouch == 2:
                print("Family Time discount: Enter fam at checkout to get 15% off")
            elif vouch == 3:
                print("Weekend Special discount: Enter party at checkout to get 5% off")
            elif vouch == 4:
                print("Student Discount: Enter std at checkout to get 5% off")
            elif vouch == 5:
                print("Sir Khawaja Discount: Enter SK at checkout to get 75% off")
            else:
                print("Invalid option chosen.")
            login = input("\nEnter Y/y if you want to get access to the menu or N/n if you don't: ")
        elif option == 4:
            print("You chose Exiting\nThank you for visiting")
            break
        elif option == 5:
            print(f"You chose Checkout\nYour current bill is {total_bill} Rps. Use vouchers for discounts.")
            disc = input("Do you have a voucher? (Y/N): ")
            if disc.lower() == 'y':
                code = input("Enter voucher code: ")
                if code == "HBD":
                    total_bill *= 0.95
                    print("5% Birthday discount applied.")
                elif code == "fam":
                    total_bill *= 0.85
                    print("15% Family Time discount applied.")
                elif code == "party":
                    total_bill *= 0.95
                    print("5% Weekend discount applied.")
                elif code == "std":
                    total_bill *= 0.95
                    print("5% Student discount applied.")
                elif code == "SK":
                    total_bill *= 0.25
                    print("75% Sir Khawaja discount applied.")
                else:
                    print("Invalid voucher code. No discount applied.")
                
            print(f"Your bill before GST is {total_bill} Rps.")
            pay = int(input("\nEnter your way of payment\n1. Card (5% tax)\n2. Cash (15% tax)\nYou chose: "))
            if pay == 1:
                last_bill = total_bill + (total_bill * 0.05)
                print(f"You chose Card. Final bill with tax (5%) is: {last_bill} Rps. Thanks for shopping with us. Bye, take care!")
            elif pay == 2:
                last_bill = total_bill + (total_bill * 0.15)
                print(f"You chose Cash. Final bill with tax (15%) is: {last_bill} Rps. Thanks for shopping with us. Bye, take care!")
            login = input("\nEnter Y/y if you want to get access to the menu or N/n if you don't: ")

# Run the main function
main()
